import argparse
import os
import socket
import threading
import time
from collections import deque
from typing import Callable, Deque, Dict, List, Optional, Tuple

import tkinter as tk
from tkinter import ttk, messagebox

from lp import recv_json, send_json


COLOR = {
    0: "#111",
    1: "#6cf",
    2: "#fd6",
    3: "#c6f",
    4: "#6f6",
    5: "#f66",
    6: "#69f",
    7: "#fa6",
}

PREVIEW_SHAPES = {
    "I": [(0, 1), (1, 1), (2, 1), (3, 1)],
    "O": [(1, 0), (2, 0), (1, 1), (2, 1)],
    "T": [(1, 0), (0, 1), (1, 1), (2, 1)],
    "S": [(1, 0), (2, 0), (0, 1), (1, 1)],
    "Z": [(0, 0), (1, 0), (1, 1), (2, 1)],
    "J": [(0, 0), (0, 1), (1, 1), (2, 1)],
    "L": [(2, 0), (0, 1), (1, 1), (2, 1)],
}
PIECE_COLORS = {
    "I": COLOR[1],
    "O": COLOR[2],
    "T": COLOR[3],
    "S": COLOR[4],
    "Z": COLOR[5],
    "J": COLOR[6],
    "L": COLOR[7],
}


class GameClient:
    def __init__(
        self,
        host: str,
        port: int,
        room_id: int,
        user_id: int,
        token: str,
        root: Optional[tk.Misc] = None,
        on_back_to_lobby: Optional[Callable[[], None]] = None,
        spectate: bool = False,
    ):
        self.host = host
        self.port = port
        self.room_id = room_id
        self.user_id = user_id
        self.token = token
        self.seq = 1
        self.primary_user_id = user_id
        self.secondary_user_id: Optional[int] = None
        self.role = "?"
        self.current_mode: Optional[str] = None
        self.line_target = 20
        self.time_limit = 0
        self.game_over = False
        self.on_back_to_lobby = on_back_to_lobby
        self.last_lines: Dict[int, int] = {}
        self.sock: Optional[socket.socket] = None
        self.snapshots: Dict[int, Dict] = {}
        self.player_meta: List[Dict] = []
        self.player_order: List[int] = []
        self.is_spectator = spectate
        self.flash_until: Dict[int, float] = {}
        self.render_delay = 0.15
        self.snapshot_history: Dict[int, Deque[Tuple[float, Dict]]] = {}

        self.own_root = False
        if root is None:
            self.root = tk.Tk()
            self.root.title("Tetris Duel")
            self.own_root = True
            container = self.root
        else:
            container = root
            self.root = root.winfo_toplevel()

        self.primary_cell = 22
        self.opp_cell = 12

        self.frame = tk.Frame(container, bg="#05060a")
        self.frame.grid(row=0, column=0, sticky="nsew")
        self.content = tk.Frame(self.frame, bg="", padx=10, pady=10)
        self.content.pack(fill=tk.BOTH, expand=True)

        top_info = tk.Frame(self.content, bg="")
        top_info.pack(fill=tk.X, pady=(0, 2))
        names = tk.Frame(top_info, bg="")
        names.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.primary_name_var = tk.StringVar(value="Primary")
        self.secondary_name_var = tk.StringVar(value="Secondary")
        tk.Label(names, textvariable=self.primary_name_var, font=("Segoe UI", 11, "bold")).pack(side=tk.LEFT, padx=8)
        tk.Label(names, textvariable=self.secondary_name_var, font=("Segoe UI", 10)).pack(side=tk.LEFT, padx=8)

        stats = tk.Frame(self.content, bg="")
        stats.pack(fill=tk.X, pady=(2, 2))
        self.lines_self_var = tk.StringVar(value="Lines: 0 | Score: 0")
        self.lines_opp_var = tk.StringVar(value="Lines: 0 | Score: 0")
        tk.Label(stats, textvariable=self.lines_self_var).pack(side=tk.LEFT, padx=6)
        tk.Label(stats, textvariable=self.lines_opp_var).pack(side=tk.LEFT, padx=6)

        self.mode_var = tk.StringVar(value="Mode: --")
        self.timer_var = tk.StringVar(value="")
        tk.Label(self.content, textvariable=self.mode_var, font=("Segoe UI", 12, "bold")).pack(anchor="w", pady=(4, 0))
        tk.Label(self.content, textvariable=self.timer_var).pack(anchor="w")

        self.info = tk.StringVar(value="Connecting...")
        tk.Label(self.content, textvariable=self.info, fg="#dddddd").pack(anchor="w", pady=(4, 0))

        boards = tk.Frame(self.content, bg="")
        boards.pack()
        boards.columnconfigure(0, weight=0)
        boards.columnconfigure(1, weight=0)
        self.canvas = tk.Canvas(
            boards,
            width=10 * self.primary_cell,
            height=20 * self.primary_cell,
            bg="#050b16",
            highlightthickness=0,
        )
        self.canvas.grid(row=0, column=0, sticky="n", padx=(0, 10), pady=4)

        opp_block = tk.Frame(boards, bg="")
        opp_block.grid(row=0, column=1, sticky="s", padx=4, pady=(10, 4))
        preview_panel = tk.Frame(opp_block, bg="")
        preview_panel.pack(anchor="center", pady=(0, 6))
        ttk.Label(preview_panel, text="Next", font=("Segoe UI", 10, "bold")).pack(anchor="center")
        self.preview_canvas = tk.Canvas(preview_panel, width=90, height=110, bg="#0b121f", highlightthickness=0)
        self.preview_canvas.pack(pady=(4, 0))
        ttk.Label(opp_block, text="Opponent", font=("Segoe UI", 10, "bold")).pack(anchor="center")
        self.canvas_opp = tk.Canvas(
            opp_block,
            width=10 * self.opp_cell,
            height=20 * self.opp_cell,
            bg="#0a0f1c",
            highlightthickness=0,
        )
        self.canvas_opp.pack(padx=2, pady=(4, 0))

        controls = tk.Frame(self.content, bg="")
        controls.pack(fill=tk.X, pady=(4, 0))
        ttk.Button(controls, text="Leave Match", command=self.leave_match).pack(side=tk.LEFT)
        ttk.Button(controls, text="Back to Lobby", command=self.back_to_lobby).pack(side=tk.RIGHT)

        bind_root = self.root if self.own_root else container.winfo_toplevel()
        bind_root.bind("<Left>", lambda e: self.send_input("LEFT"))
        bind_root.bind("<Right>", lambda e: self.send_input("RIGHT"))
        bind_root.bind("<Up>", lambda e: self.send_input("CW"))
        bind_root.bind("<Down>", lambda e: self.send_input("SOFT"))
        bind_root.bind("<space>", lambda e: self.send_input("HARD"))
        bind_root.bind("<Shift_L>", lambda e: self.send_input("HOLD"))

    def connect(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((self.host, self.port))
        send_json(
            s,
            {
                "type": "HELLO",
                "version": 1,
                "roomId": self.room_id,
                "userId": self.user_id,
                "roomToken": self.token,
                "spectate": self.is_spectator,
            },
        )
        resp = recv_json(s)
        if resp.get("type") != "WELCOME":
            raise RuntimeError("failed to join game")
        self.role = resp.get("role", "?")
        self.is_spectator = self.role == "SPEC"
        self.player_meta = resp.get("players") or []
        self.player_order = [item.get("userId") for item in self.player_meta if item.get("userId") is not None]
        self.assign_view_targets()
        self.line_target = resp.get("lineTarget") or self.line_target
        self.time_limit = resp.get("timeLimit") or self.time_limit
        self.current_mode = resp.get("mode", self.current_mode)
        self.info.set("Spectating match" if self.is_spectator else f"Joined as {self.role}")
        self.update_mode_banner({"mode": self.current_mode, "lineTarget": self.line_target, "timeLeft": self.time_limit})
        self.sock = s
        threading.Thread(target=self.recv_loop, daemon=True).start()
        self.root.after(100, self.render)

    def send_input(self, action: str):
        if not self.sock or self.is_spectator or self.game_over:
            return
        pkt = {"type": "INPUT", "userId": self.user_id, "seq": self.seq, "ts": int(time.time() * 1000), "action": action}
        self.seq += 1
        try:
            send_json(self.sock, pkt)
        except Exception:
            pass

    def recv_loop(self):
        try:
            while True:
                msg = recv_json(self.sock)
                if msg.get("type") == "SNAPSHOT":
                    self.handle_snapshot(msg)
                elif msg.get("type") == "GAME_OVER":
                    self.root.after(0, self.handle_game_over, msg)
                    break
        except Exception:
            if not self.game_over:
                self.info.set("Disconnected")

    def handle_snapshot(self, snap: Dict) -> None:
        uid = snap.get("userId")
        if uid is None:
            return
        self.snapshots[uid] = snap
        self.record_snapshot(uid, snap)
        self.update_stats_for(uid, snap)
        self.update_mode_banner(snap)
        if uid == self.primary_user_id:
            self.update_preview(snap.get("next"))
        prev = self.last_lines.get(uid, 0)
        cur = snap.get("lines", 0)
        if cur > prev:
            self.flash_until[uid] = time.time() + 0.25
        self.last_lines[uid] = cur

    def record_snapshot(self, uid: int, snap: Dict) -> None:
        history = self.snapshot_history.setdefault(uid, deque())
        now_ts = time.time()
        history.append((now_ts, snap))
        cutoff = now_ts - max(self.render_delay * 4, 1.0)
        while history and history[0][0] < cutoff:
            history.popleft()

    def get_buffered_snapshot(self, user_id: Optional[int]) -> Optional[Dict]:
        if user_id is None:
            return None
        history = self.snapshot_history.get(user_id)
        if not history:
            return self.snapshots.get(user_id)
        target = time.time() - self.render_delay
        candidate: Optional[Dict] = None
        for ts, snap in history:
            if ts <= target:
                candidate = snap
            else:
                break
        if candidate is not None:
            return candidate
        return history[0][1]

    def render_board(self, canvas: tk.Canvas, rle: str, cell: int, highlight: bool = False):
        canvas.delete("all")
        flat = []
        if rle:
            for tok in rle.split(","):
                v, c = tok.split(":")
                flat.extend([int(v)] * int(c))
        for y in range(20):
            for x in range(10):
                v = flat[y * 10 + x] if y * 10 + x < len(flat) else 0
                color = COLOR.get(v, "#333")
                canvas.create_rectangle(x * cell, y * cell, (x + 1) * cell, (y + 1) * cell, fill=color, outline="#111")
        if highlight:
            canvas.create_rectangle(0, 0, 10 * cell, 20 * cell, fill="#ffffff", outline="", stipple="gray25")

    def render(self):
        snap_primary = self.get_buffered_snapshot(self.primary_user_id)
        if snap_primary:
            self.render_board(
                self.canvas,
                snap_primary.get("boardRLE", ""),
                self.primary_cell,
                self.flash_active(self.primary_user_id),
            )
        else:
            self.canvas.delete("all")
        if self.secondary_user_id:
            snap_secondary = self.get_buffered_snapshot(self.secondary_user_id)
            if snap_secondary:
                self.render_board(
                    self.canvas_opp,
                    snap_secondary.get("boardRLE", ""),
                    self.opp_cell,
                    self.flash_active(self.secondary_user_id),
                )
            else:
                self.canvas_opp.delete("all")
        self.root.after(100, self.render)

    def flash_active(self, user_id: Optional[int]) -> bool:
        if user_id is None:
            return False
        return time.time() < self.flash_until.get(user_id, 0)

    def run(self):
        self.connect()
        if self.own_root:
            self.root.mainloop()

    def update_stats_for(self, user_id: int, snap: Dict) -> None:
        text = f"{self.player_name(user_id)}: {snap.get('lines', 0)} lines | {snap.get('score', 0)} pts"
        if user_id == self.primary_user_id:
            self.lines_self_var.set(text)
        elif self.secondary_user_id and user_id == self.secondary_user_id:
            self.lines_opp_var.set(text)

    def player_name(self, user_id: Optional[int]) -> str:
        if user_id is None:
            return "Unknown"
        for meta in self.player_meta:
            if meta.get("userId") == user_id:
                username = meta.get("username")
                if username:
                    return f"@{username}"
                return meta.get("name") or meta.get("displayName") or f"Player {user_id}"
        return f"Player {user_id}"

    def assign_view_targets(self) -> None:
        if self.is_spectator and self.player_order:
            self.primary_user_id = self.player_order[0]
            self.secondary_user_id = self.player_order[1] if len(self.player_order) > 1 else None
        else:
            self.primary_user_id = self.user_id
            others = [uid for uid in self.player_order if uid != self.user_id]
            self.secondary_user_id = others[0] if others else None
        self.update_name_labels()

    def update_name_labels(self) -> None:
        self.primary_name_var.set(self.player_name(self.primary_user_id))
        if self.secondary_user_id:
            self.secondary_name_var.set(self.player_name(self.secondary_user_id))
        else:
            self.secondary_name_var.set("Waiting for opponent")

    def mode_title(self, mode: Optional[str]) -> str:
        if mode == "survival":
            return "Mode: Survival"
        if mode == "lines":
            return f"Mode: Line Race ({self.line_target} lines)"
        if mode == "timed":
            mins = max(1, int((self.time_limit or 180) / 60))
            return f"Mode: Timed Duel ({mins} min)"
        return "Mode: --"

    def update_mode_banner(self, snap: Dict) -> None:
        mode = snap.get("mode") or self.current_mode
        if mode:
            self.current_mode = mode
        line_target = snap.get("lineTarget")
        if line_target:
            self.line_target = line_target
        time_left = snap.get("timeLeft")
        self.mode_var.set(self.mode_title(self.current_mode))
        if self.current_mode == "timed":
            if time_left is not None:
                self.timer_var.set(f"Time left: {time_left}s")
            else:
                self.timer_var.set("Time left: --")
        elif self.current_mode == "lines":
            self.timer_var.set(f"First to {self.line_target} lines wins")
        elif self.current_mode == "survival":
            self.timer_var.set("Last player alive wins")
        else:
            self.timer_var.set("")

    def update_preview(self, pieces: Optional[List[str]]) -> None:
        self.preview_canvas.delete("all")
        if not pieces:
            return
        size = 18
        for idx, shape in enumerate(pieces[:3]):
            offset_y = idx * 36
            for (dx, dy) in PREVIEW_SHAPES.get(shape, []):
                self.preview_canvas.create_rectangle(
                    dx * size,
                    offset_y + dy * size,
                    (dx + 1) * size,
                    offset_y + (dy + 1) * size,
                    fill=PIECE_COLORS.get(shape, "#999"),
                    outline="#111",
                )

    def leave_match(self) -> None:
        self.game_over = True
        if self.sock:
            try:
                self.sock.close()
            except Exception:
                pass
        self.info.set("Left match")

    def back_to_lobby(self) -> None:
        self.leave_match()
        if self.on_back_to_lobby:
            self.on_back_to_lobby()
        if self.own_root:
            self.root.destroy()

    def handle_game_over(self, payload: Dict) -> None:
        self.game_over = True
        winner = payload.get("winnerId")
        reason = payload.get("reason", "finished")
        self.render()
        summary = payload.get("summary", [])
        lines = [f"Match result ({reason}):"]
        for item in summary:
            lines.append(
                f" - {self.player_name(item.get('userId'))}: {item.get('lines', 0)} lines, {item.get('score', 0)} pts"
            )
        if winner is None:
            lines.append("Result: draw")
        elif winner == self.user_id:
            lines.append("Result: you win!")
        else:
            lines.append(f"Winner: {self.player_name(winner)}")
        messagebox.showinfo("Game Over", "\n".join(lines), parent=self.root)


def main() -> None:
    parser = argparse.ArgumentParser(description="Tetris GUI client")
    parser.add_argument("--host", default=os.getenv("GAME_HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.getenv("GAME_PORT", "31000")))
    parser.add_argument("--room-id", type=int, default=int(os.getenv("GAME_ROOM_ID", "0")))
    parser.add_argument("--user-id", type=int, default=int(os.getenv("PLAYER_ID", "0")))
    parser.add_argument("--token", default=os.getenv("GAME_ROOM_TOKEN", ""))
    parser.add_argument("--spectate", action="store_true", help="Join as spectator")
    args = parser.parse_args()

    host = os.getenv("GAME_HOST", args.host)
    port = int(os.getenv("GAME_PORT", args.port))
    room_id = int(os.getenv("GAME_ROOM_ID", args.room_id))
    user_id = int(os.getenv("PLAYER_ID", args.user_id))
    token = os.getenv("GAME_ROOM_TOKEN", args.token)
    if not port or not token or not room_id:
        raise SystemExit("Missing GAME_PORT/GAME_ROOM_TOKEN/GAME_ROOM_ID environment variables")

    client = GameClient(host, port, room_id, user_id, token, spectate=args.spectate)
    client.run()


if __name__ == "__main__":
    main()
