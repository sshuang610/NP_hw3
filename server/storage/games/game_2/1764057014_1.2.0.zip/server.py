"""
Tetris Game Server for np_hw3 platform
Adapted from HW2 game_server with environment variable integration
"""
import argparse
import json
import os
import random
import socket
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set

# Use bundled lp.py from template
from lp import recv_json, send_json

BOARD_W, BOARD_H = 10, 20

# Tetromino shapes with rotation data
PIECES = {
    "I": [
        [(0, 1), (1, 1), (2, 1), (3, 1)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
        [(0, 2), (1, 2), (2, 2), (3, 2)],
        [(1, 0), (1, 1), (1, 2), (1, 3)],
    ],
    "O": [[(1, 0), (2, 0), (1, 1), (2, 1)]] * 4,
    "T": [
        [(1, 0), (0, 1), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (1, 2)],
        [(1, 0), (0, 1), (1, 1), (1, 2)],
    ],
    "S": [
        [(1, 0), (2, 0), (0, 1), (1, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
        [(1, 1), (2, 1), (0, 2), (1, 2)],
        [(0, 0), (0, 1), (1, 1), (1, 2)],
    ],
    "Z": [
        [(0, 0), (1, 0), (1, 1), (2, 1)],
        [(2, 0), (1, 1), (2, 1), (1, 2)],
        [(0, 1), (1, 1), (1, 2), (2, 2)],
        [(1, 0), (0, 1), (1, 1), (0, 2)],
    ],
    "J": [
        [(0, 0), (0, 1), (1, 1), (2, 1)],
        [(1, 0), (2, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (0, 2), (1, 2)],
    ],
    "L": [
        [(2, 0), (0, 1), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 1), (0, 2)],
        [(0, 0), (1, 0), (1, 1), (1, 2)],
    ],
}


def rle_encode(flat: List[int]) -> str:
    """RLE encode board data for efficient transmission"""
    out = []
    i = 0
    n = len(flat)
    while i < n:
        v = flat[i]
        j = i + 1
        while j < n and flat[j] == v and j - i < 255:
            j += 1
        out.append(f"{v}:{j - i}")
        i = j
    return ",".join(out)


@dataclass
class Active:
    """Current falling piece"""
    shape: str
    rot: int
    x: int
    y: int


@dataclass
class Player:
    """Player state"""
    player_id: int
    username: str
    role: str  # "primary" or "secondary"
    board: List[int] = field(default_factory=lambda: [0] * (BOARD_W * BOARD_H))
    active: Optional[Active] = None
    hold: Optional[str] = None
    can_hold: bool = True
    nextq: List[str] = field(default_factory=list)
    score: int = 0
    lines: int = 0
    alive: bool = True


class TetrisServer:
    def __init__(self, host: str, port: int, room_id: int, room_token: str):
        self.host = host
        self.port = port
        self.room_id = room_id
        self.room_token = room_token
        
        self.clients: Dict[socket.socket, Dict] = {}
        self.players: Dict[int, Player] = {}
        self.client_by_player: Dict[int, socket.socket] = {}
        
        self.seed = random.randint(1, 2**31 - 1)
        self.random = random.Random(self.seed)
        self.bag: List[str] = []
        
        self.gravity_ms = 600
        self.start_time = 0.0
        
        self.running = True
        self.lock = threading.Lock()
        self.winner_id: Optional[int] = None

    def next_piece(self) -> str:
        """7-bag random generator"""
        if not self.bag:
            bag = list(PIECES.keys())
            self.random.shuffle(bag)
            self.bag.extend(bag)
        return self.bag.pop()

    def spawn_piece(self, p: Player) -> bool:
        """Spawn new piece for player"""
        shape = p.nextq.pop(0) if p.nextq else self.next_piece()
        while len(p.nextq) < 5:
            p.nextq.append(self.next_piece())
        
        act = Active(shape=shape, rot=0, x=3, y=0)
        if not self.can_place(p.board, act):
            p.alive = False
            return False
        p.active = act
        p.can_hold = True
        return True

    def can_place(self, board: List[int], act: Active) -> bool:
        """Check if piece can be placed at position"""
        for (dx, dy) in PIECES[act.shape][act.rot]:
            x, y = act.x + dx, act.y + dy
            if not (0 <= x < BOARD_W and 0 <= y < BOARD_H) or board[y * BOARD_W + x] != 0:
                return False
        return True

    def lock_piece(self, p: Player):
        """Lock piece to board and clear lines"""
        act = p.active
        if not act:
            return
        
        shape_id = list(PIECES.keys()).index(act.shape) + 1
        for (dx, dy) in PIECES[act.shape][act.rot]:
            x, y = act.x + dx, act.y + dy
            if 0 <= x < BOARD_W and 0 <= y < BOARD_H:
                p.board[y * BOARD_W + x] = shape_id
        
        p.active = None
        cleared = self.clear_lines(p)
        
        # Scoring
        if cleared == 1:
            p.score += 100
        elif cleared == 2:
            p.score += 300
        elif cleared == 3:
            p.score += 500
        elif cleared == 4:
            p.score += 800
        p.lines += cleared

    def clear_lines(self, p: Player) -> int:
        """Clear full lines and return count"""
        new_board = [0] * (BOARD_W * BOARD_H)
        ny = BOARD_H - 1
        cleared = 0
        
        for y in range(BOARD_H - 1, -1, -1):
            row = p.board[y * BOARD_W:(y + 1) * BOARD_W]
            if all(v != 0 for v in row):
                cleared += 1
            else:
                new_board[ny * BOARD_W:(ny + 1) * BOARD_W] = row
                ny -= 1
        
        p.board = new_board
        return cleared

    def apply_input(self, player_id: int, action: str):
        """Handle player input"""
        with self.lock:
            p = self.players.get(player_id)
            if not p or not p.alive or not p.active:
                return
            
            act = p.active
            
            if action == "LEFT":
                new_act = Active(act.shape, act.rot, act.x - 1, act.y)
                if self.can_place(p.board, new_act):
                    p.active = new_act
            
            elif action == "RIGHT":
                new_act = Active(act.shape, act.rot, act.x + 1, act.y)
                if self.can_place(p.board, new_act):
                    p.active = new_act
            
            elif action in ("CW", "CCW"):
                new_rot = (act.rot + 1) % 4 if action == "CW" else (act.rot - 1) % 4
                new_act = Active(act.shape, new_rot, act.x, act.y)
                # Simple wall kick
                for ox in [0, -1, 1, -2, 2]:
                    test = Active(new_act.shape, new_act.rot, new_act.x + ox, new_act.y)
                    if self.can_place(p.board, test):
                        p.active = test
                        break
            
            elif action == "SOFT":
                new_act = Active(act.shape, act.rot, act.x, act.y + 1)
                if self.can_place(p.board, new_act):
                    p.active = new_act
                else:
                    self.lock_piece(p)
                    self.spawn_piece(p)
            
            elif action == "HARD":
                while True:
                    new_act = Active(act.shape, act.rot, act.x, act.y + 1)
                    if self.can_place(p.board, new_act):
                        p.active = new_act
                    else:
                        break
                self.lock_piece(p)
                self.spawn_piece(p)
                p.score += 2
            
            elif action == "HOLD":
                if not p.can_hold:
                    return
                cur = act.shape
                if p.hold is None:
                    p.hold = cur
                    p.active = None
                    self.spawn_piece(p)
                else:
                    p.hold, cur = cur, p.hold
                    p.active = Active(cur, 0, 3, 0)
                    if not self.can_place(p.board, p.active):
                        p.alive = False
                p.can_hold = False

    def gravity_step(self):
        """Apply gravity to all players"""
        with self.lock:
            for p in self.players.values():
                if not p.alive or not p.active:
                    continue
                act = p.active
                new_act = Active(act.shape, act.rot, act.x, act.y + 1)
                if self.can_place(p.board, new_act):
                    p.active = new_act
                else:
                    self.lock_piece(p)
                    self.spawn_piece(p)

    def check_game_over(self) -> bool:
        """Check win conditions - Survival mode: last player alive wins"""
        with self.lock:
            alive = [p for p in self.players.values() if p.alive]
            if len(alive) == 1:
                self.winner_id = alive[0].player_id
                return True
            elif len(alive) == 0:
                return True
        
        return False

    def broadcast_snapshot(self):
        """Send game state to all clients"""
        with self.lock:
            snapshot = {
                "type": "SNAPSHOT",
                "tick": int(time.time() * 1000),
                "players": []
            }
            
            for p in self.players.values():
                # Build current board state
                board = p.board[:]
                if p.active:
                    shape_id = list(PIECES.keys()).index(p.active.shape) + 1
                    for (dx, dy) in PIECES[p.active.shape][p.active.rot]:
                        x, y = p.active.x + dx, p.active.y + dy
                        if 0 <= x < BOARD_W and 0 <= y < BOARD_H:
                            board[y * BOARD_W + x] = shape_id
                
                snapshot["players"].append({
                    "playerId": p.player_id,
                    "role": p.role,
                    "board": rle_encode(board),
                    "score": p.score,
                    "lines": p.lines,
                    "nextq": p.nextq[:3],
                    "hold": p.hold,
                    "alive": p.alive,
                })
            
            for conn in list(self.clients.keys()):
                try:
                    send_json(conn, snapshot)
                except Exception:
                    pass

    def game_loop(self):
        """Main game loop"""
        last_gravity = time.time()
        
        while self.running:
            time.sleep(0.05)
            
            # Wait for players
            if self.start_time == 0:
                with self.lock:
                    if len(self.players) >= 2:
                        self.start_time = time.time()
                continue
            
            # Apply gravity
            now = time.time()
            if now - last_gravity >= self.gravity_ms / 1000.0:
                self.gravity_step()
                last_gravity = now
            
            # Check game over
            if self.check_game_over():
                self.running = False
                break

    def snapshot_loop(self):
        """Broadcast snapshots periodically"""
        while self.running:
            self.broadcast_snapshot()
            time.sleep(0.2)

    def handle_client(self, conn: socket.socket):
        """Handle client connection"""
        try:
            # Receive HELLO
            hello = recv_json(conn)
            if hello.get("type") != "HELLO":
                send_json(conn, {"ok": False, "error": "expected HELLO"})
                conn.close()
                return
            
            room_token = hello.get("roomToken") or hello.get("token")
            if hello.get("roomId") != self.room_id or room_token != self.room_token:
                send_json(conn, {"ok": False, "error": "invalid room credentials"})
                conn.close()
                return
            
            player_id = int(hello.get("playerId") or hello.get("userId"))
            username = hello.get("username", f"Player{player_id}")
            
            # Create player
            with self.lock:
                if len(self.players) >= 2:
                    send_json(conn, {"ok": False, "error": "room full"})
                    conn.close()
                    return
                
                role = "primary" if len(self.players) == 0 else "secondary"
                player = Player(player_id=player_id, username=username, role=role)
                
                # Initialize nextq and spawn first piece
                while len(player.nextq) < 5:
                    player.nextq.append(self.next_piece())
                self.spawn_piece(player)
                
                self.players[player_id] = player
                self.clients[conn] = {"playerId": player_id}
                self.client_by_player[player_id] = conn
            
            # Send WELCOME with current players list
            with self.lock:
                players_list = [
                    {"playerId": p.player_id, "username": p.username, "role": p.role}
                    for p in self.players.values()
                ]
            send_json(conn, {
                "type": "WELCOME",
                "role": role,
                "playerId": player_id,
                "boardWidth": BOARD_W,
                "boardHeight": BOARD_H,
                "players": players_list,
                "mode": "survival",
            })
            
            # Handle INPUT messages
            while self.running:
                msg = recv_json(conn)
                if msg.get("type") == "INPUT":
                    self.apply_input(player_id, msg.get("action"))
        
        except Exception as e:
            print(f"[Game] client error: {e}")
        finally:
            with self.lock:
                self.clients.pop(conn, None)
                if player_id in self.client_by_player:
                    del self.client_by_player[player_id]
            try:
                conn.close()
            except:
                pass

    def serve(self):
        """Start server"""
        print(f"[Tetris] Starting server on {self.host}:{self.port}")
        print(f"[Tetris] Room {self.room_id}, Mode: survival")
        
        # Start game loops
        threading.Thread(target=self.game_loop, daemon=True).start()
        threading.Thread(target=self.snapshot_loop, daemon=True).start()
        
        # Accept connections
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((self.host, self.port))
            s.listen()
            print(f"[Tetris] Listening on {self.host}:{self.port}")
            
            while self.running:
                try:
                    conn, addr = s.accept()
                    threading.Thread(target=self.handle_client, args=(conn,), daemon=True).start()
                except Exception:
                    break


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default=os.getenv("GAME_SERVER_HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.getenv("GAME_SERVER_PORT", "0")))
    args = parser.parse_args()
    
    # Get environment variables set by lobby server
    room_id = int(os.getenv("GAME_ROOM_ID", "0"))
    room_token = os.getenv("GAME_ROOM_TOKEN", "")
    
    if not room_id or not room_token:
        print("[Tetris] Error: Missing GAME_ROOM_ID or GAME_ROOM_TOKEN environment variables")
        return
    
    server = TetrisServer(args.host, args.port, room_id, room_token)
    server.serve()


if __name__ == "__main__":
    main()
