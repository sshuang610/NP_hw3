import os
import socket
import sys
from typing import Dict, List

from lp import recv_json, send_json

SYMBOLS = {0: ".", 1: "X", 2: "O", 3: "A", 4: "B"}


def render_board(board: List[List[int]]) -> str:
    rows = []
    for row in board:
        cells = " ".join(SYMBOLS.get(cell, "?") for cell in row)
        rows.append(f"| {cells} |")
    footer = "  " + " ".join(str(idx) for idx in range(len(board[0])))
    return "\n".join(rows + [footer])


def main() -> None:
    host = os.getenv("GAME_HOST", "127.0.0.1")
    port = int(os.getenv("GAME_PORT", "31000"))
    room_token = os.getenv("GAME_ROOM_TOKEN", "")
    player_id = int(os.getenv("PLAYER_ID", "0"))
    display_name = os.getenv("PLAYER_DISPLAY_NAME", f"Player {player_id}")

    print(f"Connecting to Connect4 server {host}:{port} as {display_name}")

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.connect((host, port))
        send_json(
            sock,
            {
                "type": "HELLO",
                "playerId": player_id,
                "displayName": display_name,
                "roomToken": room_token,
            },
        )
        slot = None
        symbol = None
        board: List[List[int]] = []
        while True:
            msg = recv_json(sock)
            mtype = msg.get("type")
            if mtype == "WELCOME":
                slot = msg.get("slot")
                symbol = msg.get("symbol")
                board = msg.get("board", board)
                print("Connected! Assigned slot", slot, "symbol", symbol)
                print(render_board(board))
            elif mtype == "READY":
                board = msg.get("board", board)
                names = [p.get("displayName", f"Player {p.get('slot', '?')}") for p in msg.get("players", [])]
                print("Players ready:", ", ".join(names))
                print(render_board(board))
            elif mtype == "BOARD_STATE":
                board = msg.get("board", board)
                last = msg.get("lastMove")
                if last:
                    mover = last.get("slot")
                    column = last.get("column")
                    if mover is not None:
                        if mover == slot:
                            print(f"You placed a piece in column {column}.")
                        else:
                            print(f"Opponent placed in column {column}.")
                print(render_board(board))
            elif mtype == "YOUR_TURN":
                board = msg.get("board", board)
                print(render_board(board))
                max_col = len(board[0]) - 1 if board and board[0] else msg.get("columnCount", 7) - 1
                while True:
                    raw = input(f"Choose a column (0-{max_col}): ")
                    try:
                        column = int(raw.strip())
                    except ValueError:
                        print("Please enter a valid number.")
                        continue
                    send_json(sock, {"type": "MOVE", "column": column})
                    break
            elif mtype == "INVALID_MOVE":
                reason = msg.get("message", "Invalid move")
                print(f"Server rejected move: {reason}")
            elif mtype == "GAME_OVER":
                board = msg.get("board", board)
                winner = msg.get("winnerSlot")
                reason = msg.get("reason")
                print(render_board(board))
                if winner is None:
                    if reason == "draw":
                        print("Game finished in a draw!")
                    else:
                        print("Game ended without a winner (", reason, ")")
                elif winner == slot:
                    print("Congratulations, you win!")
                else:
                    print("You lose this round. GG!")
                break
            else:
                print("Received:", msg)
    print("Connection closed.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
